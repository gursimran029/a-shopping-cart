/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sheridan.finalmavenproject1;

/**
 *
 * @author gursi
 */
public class DiscountFactory {
    

 static DiscountFactory discountFactoryInstance = null;

private DiscountFactory()
{
    
}


// Mujda F. we are doing this, because factory has to be singleton
public static DiscountFactory getInstance()
{
    if(discountFactoryInstance == null)
    {
    	discountFactoryInstance = new DiscountFactory();
    }
    
       return discountFactoryInstance;
}


// Mujda F. here we are creating object based on type, factory method
 public Discount create(Discount.Type type, double amount)
{
    if(type == Discount.Type.AMOUNT)
    {
    	return new DiscountByAmount(amount);
    }else if(type == Discount.Type.PERCENTAGE)
    {
    	return new DiscountByPercentage(amount);
    }
    
    return null;
}



}