/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sheridan.finalmavenproject1;

/**
 *
 * @author gursi
 */
public class abstract Discount {
    

	
	protected double amount;
	
	enum Type{
		AMOUNT,
		PERCENTAGE
	}
	
	
	// Mujda F. it has constructor
	public Discount(double a)
	{
		amount = a;
	}
	
	// Mujda F. abstact method because we need to apply discount based on object that is by amount or percentage
	public abstract double applyDiscount(double price);
	
	
	
}