/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sheridan.finalmavenproject1;
        import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author gursi
 */
public class Cart {
    



    
    private List <Product> products = new ArrayList<>( );
    private PaymentService service;
    
    // Mujda F. here we are using aggregation
    private Discount discount = null;
    
    public void setPaymentService( PaymentService service ) {
        this.service  = service;
    }
    
    
    public void addProduct( Product product ) {
        products.add( product );
    }
    
    public void payCart( ) {
        double total = 0;
        
        
        
       for ( Product product : products ) {
           total += product.getPrice( );
       }
       
       // Mujda F. applyDiscount method gets us new price, after applying discount
       if(discount != null) // Mujda F. we only do it if discount exists for this cart
    	   total = discount.applyDiscount(total);
       
        service.processPayment( total );
    }
    
    
    // Mujda F. Here we setting discount
    public void addDiscount(Discount d) {
    	discount = d;
    }
}
© 2020 GitHub, Inc.